//
//  PesquisaViewController.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import UIKit

class PesquisaViewController:
    UIViewController,
    UITableViewDelegate,
    UITableViewDataSource
{
    var aeroportos:[Aeroporto] = Repositorio.obtenhaAeroportos();
    var voos:[Voo] = Infraero.filtreVoos(aeroportoDesejado: Repositorio.obtenhaAeroportos()[0], tipoDeVoo: .SAIDA)
    
    @IBOutlet weak var vrBuscaText: UITextField!
    @IBOutlet weak var vrListaDeVoos: UITableView!
    @IBOutlet weak var vrTipoDeVooSegment: UISegmentedControl!
    
    @IBOutlet weak var vrAeroportosSegment: UISegmentedControl!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.voos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let celula = self.vrListaDeVoos.dequeueReusableCell(withIdentifier: "celula") as! UITableViewCell
        celula.textLabel?.text = String(self.voos[indexPath.row].description())
        return celula
    }
    
    @IBAction func aeroportoAlterado(_ sender: UISegmentedControl)
    {
        recarregueVoos()
    }
    
    @IBAction func tipoDeVooAlterado(_ sender: UISegmentedControl)
    {
        recarregueVoos()
    }
    
    @IBAction func buscarVoos(_ sender: Any)
    {
        let tipoDeVoo = vrTipoDeVooSegment.selectedSegmentIndex == 0
            ? TipoDeVoo.SAIDA
            : TipoDeVoo.CHEGADA
        self.voos = Infraero.filtreVoos(aeroportoDesejado: Repositorio.obtenhaAeroportos()[vrAeroportosSegment.selectedSegmentIndex], tipoDeVoo: tipoDeVoo, numeroDoVoo: Int(vrBuscaText.text!))
        self.vrListaDeVoos.reloadData()
    }
    
    func recarregueVoos() -> Void
    {
        let tipoDeVoo = vrTipoDeVooSegment.selectedSegmentIndex == 0
            ? TipoDeVoo.SAIDA
            : TipoDeVoo.CHEGADA
        self.voos = Infraero.filtreVoos(aeroportoDesejado: Repositorio.obtenhaAeroportos()[vrAeroportosSegment.selectedSegmentIndex], tipoDeVoo: tipoDeVoo)
        self.vrBuscaText.text = ""
        self.vrListaDeVoos.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        vrAeroportosSegment.removeAllSegments()
        for (i, aeroporto) in aeroportos.enumerated()
        {
            vrAeroportosSegment.insertSegment(withTitle: aeroporto.sigla, at: i, animated: true)
        }
        
        vrAeroportosSegment.selectedSegmentIndex = 0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
