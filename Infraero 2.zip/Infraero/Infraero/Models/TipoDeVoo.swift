//
//  TipoDeVoo.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

enum TipoDeVoo
{
    case AMBOS
    case CHEGADA
    case SAIDA
}
