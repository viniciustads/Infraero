//
//  Aeroporto.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

class Aeroporto
{
    public var nome:String
    public var cidade:String
    public var sigla:String
    public var voos:[Voo]
    
    convenience init(nome:String)
    {
        self.init(nome: nome, voos: [Voo]())
    }
        
    init(nome:String, voos:[Voo])
    {
        self.nome = nome
        self.cidade = ""
        self.sigla = ""
        self.voos = voos
    }
    
    convenience init(nome:String, cidade:String, sigla:String)
    {
        self.init(nome: nome, cidade: cidade, sigla: sigla, voos: [Voo]())
    }
    
    init(nome:String, cidade:String, sigla:String, voos:[Voo])
    {
        self.nome = nome
        self.cidade = cidade
        self.sigla = sigla
        self.voos = voos
    }
    
    func insiraVoo(voo: Voo) -> Void
    {
        self.voos.append(voo)
    }
    
    static func ==(lhs:Aeroporto, rhs:Aeroporto) -> Bool {
        return lhs.sigla == rhs.sigla
    }
}
