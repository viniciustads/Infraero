//
//  Infraero.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

class Infraero
{
    static func obtenhaTodosVoos() -> [Voo]
    {
        var voos:[Voo] = [Voo]()
        for aeroporto in Repositorio.obtenhaAeroportos()
        {
            voos.append(contentsOf: aeroporto.voos)
        }
        
        return voos
    }
    
    static func filtreVoos(sigla: String)->[Voo]
    {
        var voosFiltrados:[Voo] = [Voo]()
        for aeroporto in Repositorio.obtenhaAeroportos()
        {
            if(aeroporto.sigla.lowercased() == sigla.lowercased())
            {
                voosFiltrados.append(contentsOf: aeroporto.voos)
                break
            }
        }
        
        return voosFiltrados
    }
    
    static func filtreVoos(aeroportoDesejado: Aeroporto, tipoDeVoo: TipoDeVoo, numeroDoVoo:Int? = nil) -> [Voo]
    {
        var voosFiltrados:[Voo] = [Voo]()
        for aeroporto in Repositorio.obtenhaAeroportos()
        {
            if(aeroporto == aeroportoDesejado)
            {
                switch (tipoDeVoo)
                {
                    case .CHEGADA:
                        for voo in aeroporto.voos
                        {
                            if (voo.aeroportoDeDestino == aeroportoDesejado && (numeroDoVoo == nil || voo.numero == numeroDoVoo!))
                            {
                                voosFiltrados.append(voo)
                            }
                        }
                    case .SAIDA:
                        for voo in aeroporto.voos
                        {
                            if (voo.aeroportoDeOrigem == aeroportoDesejado && (numeroDoVoo == nil || voo.numero == numeroDoVoo!))
                            {
                                voosFiltrados.append(voo)
                            }
                        }
                    default:
                        voosFiltrados.append(contentsOf: aeroporto.voos)
                }
            }
        }
        
        return voosFiltrados
    }
    
    static func filtreVoos(numeroDoVoo: Int)->Voo?
    {
        for aeroporto in Repositorio.obtenhaAeroportos()
        {
            for voo in aeroporto.voos
            {
                if voo.numero == numeroDoVoo
                {
                    return voo;
                }
            }
        }
        
        return nil
    }
}
