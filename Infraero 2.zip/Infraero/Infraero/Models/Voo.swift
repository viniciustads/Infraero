//
//  Voo.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

class Voo
{
    public var numero:Int
    public var companhia:Companhia
    public var aeroportoDeOrigem:Aeroporto
    public var aeroportoDeDestino:Aeroporto
    
    init(numero: Int, companhia: Companhia, aeroportoDeOrigem: Aeroporto, aeroportoDeDestino: Aeroporto)
    {
        self.numero = numero
        self.companhia = companhia
        self.aeroportoDeOrigem = aeroportoDeOrigem
        self.aeroportoDeDestino = aeroportoDeDestino
    }
    
    func description() -> String
    {
        return "\(self.numero): \(self.companhia.nome) - \(self.aeroportoDeOrigem.sigla) -> \(self.aeroportoDeDestino.sigla)"
    }
    
    static func ==(lhs:Voo, rhs:Voo) -> Bool
    {
        return lhs.numero == rhs.numero
    }
}
