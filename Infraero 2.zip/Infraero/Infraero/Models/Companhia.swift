//
//  Companhia.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

class Companhia
{
    public var nome:String
    
    init(_ nome:String)
    {
        self.nome = nome
    }
}
