//
//  Repositorio.swift
//  Infraero
//
//  Created by Aluno on 03/03/2018.
//  Copyright © 2018 UFG. All rights reserved.
//

import Foundation

class Repositorio
{
    static func obtenhaAeroportos()->[Aeroporto]
    {
        let tam = Companhia("TAM")
        let gol = Companhia("GOL")
        let azul = Companhia("AZUL")
        let passaredo = Companhia("PASSAREDO")
        
        let aeroportoSantaGenoveva = Aeroporto(nome: "Aeroporto Santa Genoveva", cidade: "Goiânia", sigla: "GYN")
        let aeroportoVancouver = Aeroporto(nome: "Aeroporto Internacional de Vancouver", cidade: "Vancouver", sigla: "YVR")
        let aeroportoCuiaba = Aeroporto(nome: "Aeroporto Internacional de Cuiabá", cidade: "Cuiabá", sigla: "CGB")
        let aeroportoBrasilia = Aeroporto(nome: "Aeroporto Internacional de Brasília", cidade: "Brasília", sigla: "BSB")
        
        let vooSC = Voo(numero: 1, companhia: tam, aeroportoDeOrigem: aeroportoSantaGenoveva, aeroportoDeDestino: aeroportoCuiaba)
        let vooSB = Voo(numero: 2, companhia: gol, aeroportoDeOrigem: aeroportoSantaGenoveva, aeroportoDeDestino: aeroportoBrasilia)
        let vooVB = Voo(numero: 3, companhia: azul, aeroportoDeOrigem: aeroportoVancouver, aeroportoDeDestino: aeroportoBrasilia)
        let vooCS = Voo(numero: 4, companhia: passaredo, aeroportoDeOrigem: aeroportoCuiaba, aeroportoDeDestino: aeroportoSantaGenoveva)
        let vooCB = Voo(numero: 5, companhia: tam, aeroportoDeOrigem: aeroportoCuiaba, aeroportoDeDestino: aeroportoBrasilia)
        let vooBS = Voo(numero: 6, companhia: gol, aeroportoDeOrigem: aeroportoBrasilia, aeroportoDeDestino: aeroportoSantaGenoveva)
        let vooBV = Voo(numero: 7, companhia: azul, aeroportoDeOrigem: aeroportoBrasilia, aeroportoDeDestino: aeroportoVancouver)
        let vooBC = Voo(numero: 8, companhia: passaredo, aeroportoDeOrigem: aeroportoBrasilia, aeroportoDeDestino: aeroportoCuiaba)
        
        aeroportoSantaGenoveva.insiraVoo(voo: vooSC)
        aeroportoSantaGenoveva.insiraVoo(voo: vooSB)
        aeroportoSantaGenoveva.insiraVoo(voo: vooCS)
        aeroportoSantaGenoveva.insiraVoo(voo: vooBS)
        
        aeroportoVancouver.insiraVoo(voo: vooVB)
        aeroportoVancouver.insiraVoo(voo: vooBV)
                
        aeroportoCuiaba.insiraVoo(voo: vooSC)
        aeroportoCuiaba.insiraVoo(voo: vooCS)
        aeroportoCuiaba.insiraVoo(voo: vooCB)
        aeroportoCuiaba.insiraVoo(voo: vooBC)
        
        aeroportoBrasilia.insiraVoo(voo: vooSB)
        aeroportoBrasilia.insiraVoo(voo: vooVB)
        aeroportoBrasilia.insiraVoo(voo: vooCB)
        aeroportoBrasilia.insiraVoo(voo: vooBS)
        aeroportoBrasilia.insiraVoo(voo: vooBV)
        aeroportoBrasilia.insiraVoo(voo: vooBC)
        
        return [aeroportoSantaGenoveva, aeroportoVancouver, aeroportoCuiaba, aeroportoBrasilia]
    }
}
